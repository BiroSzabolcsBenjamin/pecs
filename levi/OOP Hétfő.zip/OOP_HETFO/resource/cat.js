document.addEventListener('DOMContentLoaded', ()=>{
    fetch('../controller/catController.php');
})