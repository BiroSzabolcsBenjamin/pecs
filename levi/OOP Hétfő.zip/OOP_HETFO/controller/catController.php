<?php
class catController{
    static function getAllCats(){
        try{
            
            $response = catService::getAllCats();
            echo $response;

        }catch(Exception $e){
            echo $e->getMessage();
        }
    }
}

catController::getAllCats();