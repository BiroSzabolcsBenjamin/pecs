<?php
class catService{
    static function getAllCats(){
        $modelResult = Cat::getAllCats();
        return $modelResult;
    }
}