<?php
include '../service/CatService.php';

class CatController{

    static function getCatsByGender($gender){
        http_response_code(200);
        header('Content-Type: application/json; charset=utf-8');

        $serviceResult = CatService::getCatsByGender($gender);
        echo json_encode($serviceResult);
    }
}

$gender = $_GET['gender'];
CatController::getCatsByGender($gender);