<?php
require_once '../model/Cat.php';

class CatService{
    static function getCatsByGender($genderFilter){

        $modelResult = Cat::getAllCats();
        $result = [];
        foreach($modelResult as $cat){
            if($cat->getGender() == $genderFilter){
                $result[] = [
                    'name' => $cat->getName(),
                    'color' => $cat->getColor(),
                    'birthDate' => $cat->getBirthDate()
                ];
            }
        }
        return $result;
    }
}