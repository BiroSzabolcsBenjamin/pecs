const genderInput = document.getElementById("gender_filter");
const requestButton = document.getElementById("get_cats");


requestButton.addEventListener('click',()=>{
    let gender = genderInput.value;
    fetch(`../controller/catController.php?gender=${gender}`);
})
